import React from "react";
import { Outlet, useParams, NavLink } from "react-router-dom";

import {
  Card,
  Typography,
  Box,
  CardMedia,
  Container,
  Divider,
  Tab,
  TabPanel,
  Tabs,
} from "@mui/material";

const SideBar = () => {
  return (
    <Box
      sx={{
        margin: "15px 0px",
        display: "flex",
        flexDirection: "row",
        width: "100%",
      }}
    >
      <Box
        sx={{
          backgroundColor: "#ef060630",
          borderRadius: "40px",
          marginLeft: "10px",

          alignItems: "center",
          display: "flex",
          height: "100vh",
          width: "20%",
        }}
      >
        <Box
          sx={{
            width: "100%",
            padding: "0px 10px",
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
          }}
        >
          <NavLink
            style={{
              display: "flex",
              justifyContent: "center",
              textDecoration: "none",
              color: "black",
            }}
            to="profile"
          >
            <Typography variant="h5">Profile</Typography>
          </NavLink>
          <Divider sx={{ paddingTop: "10px " }} />

          <NavLink
            style={{
              display: "flex",
              justifyContent: "center",
              textDecoration: "none",
              color: "black",
            }}
            to="posts"
          >
            <Typography sx={{ paddingTop: "10px" }} variant="h5">
              Posts
            </Typography>
          </NavLink>
          <Divider sx={{ paddingTop: "10px " }} />
          <NavLink
            style={{
              display: "flex",
              justifyContent: "center",
              textDecoration: "none",
              color: "black",
            }}
            to="gallery"
          >
            <Typography sx={{ paddingTop: "10px" }} variant="h5">
              Gallery
            </Typography>
          </NavLink>
          <Divider sx={{ paddingTop: "10px " }} />
          <NavLink
            style={{
              display: "flex",
              justifyContent: "center",
              textDecoration: "none",
              color: "black",
            }}
            to="todos"
          >
            <Typography sx={{ paddingTop: "10px" }} variant="h5">
              Todos
            </Typography>
          </NavLink>
        </Box>
      </Box>
      <Outlet />
    </Box>
  );
};

export default SideBar;
