import React from "react";
import SideBar from "./SideBar";

const Posts = () => {
  return (
    <div>
      <h1>Coming Soon</h1>
    </div>
  );
};

export default Posts;
