import React from "react";
import SideBar from "./SideBar";

const Gallery = () => {
  return (
    <div>
      <h1>Coming Soon</h1>
    </div>
  );
};

export default Gallery;
