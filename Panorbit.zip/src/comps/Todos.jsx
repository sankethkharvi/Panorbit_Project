import SideBar from "./SideBar";

import React, { useState } from "react";
import {
  Button,
  Popover,
  Typography,
  Stack,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Box,
  Avatar,
  Divider,
} from "@mui/material";
import ChatBubbleOutlineIcon from "@mui/icons-material/ChatBubbleOutline";
import KeyboardArrowUpIcon from "@mui/icons-material/KeyboardArrowUp";

const Todos = () => {
  const [anchorElChat, setAnchorElChat] = React.useState(null);

  const handleClickChat = (event) => {
    setAnchorElChat(event.currentTarget);
  };

  const handleCloseChat = () => {
    setAnchorElChat(null);
  };
  const opn = Boolean(anchorElChat);

  return (
    <Box>
      <Box
        onClick={handleClickChat}
        sx={{
          width: "50%",
          background: "blue",
          height: "4vh",
          borderRadius: "10px",
          display: "flex",
          flexDirection: "row",
        }}
      >
        <ChatBubbleOutlineIcon />
        <Typography>Chats</Typography>
        <KeyboardArrowUpIcon />
      </Box>
      <Popover
        open={opn}
        anchorElChat={anchorElChat}
        onClose={handleCloseChat}
        anchorReference="anchorElChat"
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "right",
        }}
      >
        <Stack>
          <Box
            sx={{ display: "flex", flexDirection: "row", alignItems: "center" }}
          >
            <Avatar />
            <Typography>SAI</Typography>
            <Box
              sx={{
                backgroundColor: "green",
                height: "6px",
                width: "6px",
                borderRadius: "50%",
              }}
            ></Box>
            <Divider />
          </Box>

          <Box
            sx={{ display: "flex", flexDirection: "row", alignItems: "center" }}
          >
            <Avatar />
            <Typography>SAI</Typography>
            <Box
              sx={{
                backgroundColor: "green",
                height: "6px",
                width: "6px",
                borderRadius: "50%",
              }}
            ></Box>
            <Divider />
          </Box>
        </Stack>
      </Popover>
    </Box>
  );
};

export default Todos;
