import React from "react";

const Dummy = () => {
  return <div>HI</div>;
};

export default Dummy;
