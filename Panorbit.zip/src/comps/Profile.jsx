import { useState, useEffect } from "react";
import ChatBubbleOutlineIcon from "@mui/icons-material/ChatBubbleOutline";
import KeyboardArrowUpIcon from "@mui/icons-material/KeyboardArrowUp";
import {
  Card,
  CardMedia,
  Typography,
  Divider,
  Box,
  Avatar,
  Modal,
  Stack,
  Button,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Popper,
  Popover,
} from "@mui/material";
import {
  useLocation,
  useParams,
  Link,
  Outlet,
  NavLink,
} from "react-router-dom";

const Profile = () => {
  const [anchorEl, setAnchorEl] = useState(null);

  const { iid } = useParams();
  const idInInteger = parseInt(iid) - 1;
  const data = JSON.parse(sessionStorage.getItem("myKey") || "");
  const info = data[idInInteger];

  console.log(info);
  console.log(idInInteger);
  console.log(iid);

  const [anchorElChat, setAnchorElChat] = useState(null);

  const handleClickChat = (event) => {
    setAnchorElChat(event.currentTarget);
  };

  const handleCloseChat = () => {
    setAnchorElChat(null);
  };
  const opn = Boolean(anchorElChat);

  const {
    id,
    username,
    profilepicture,
    name,
    email,
    phone,
    website,
    company,
    address,
  } = info;

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const open = Boolean(anchorEl);
  const demo = open ? "simple-popover" : undefined;

  return (
    <Box
      sx={{
        // backgroundColor: "yellow",
        display: "flex",
        width: "80%",
        height: "100vh",
        flexDirection: "column",
        marginLeft: "10px",
      }}
    >
      <Box
        sx={{
          display: "flex",
          justifyContent: "space-between",
          height: "10vh",
          width: "95%",
          alignItems: "center",
        }}
      >
        {" "}
        <Typography variant="h6">Profile</Typography>
        <Box
          aria-describedby={demo}
          variant="contained"
          onClick={handleClick}
          sx={{ display: "flex" }}
          paddingTop="10px"
        >
          <Avatar src={profilepicture} />
          <Typography variant="h6">{name}</Typography>
        </Box>
        <Popover
          id={id}
          open={open}
          anchorEl={anchorEl}
          onClose={handleClose}
          anchorOrigin={{
            vertical: "bottom",
            horizontal: "left",
          }}
        >
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              p: "2",
              width: "150px",
              height: "80px",
            }}
          >
            <NavLink
              style={{ textDecoration: "none", color: "black" }}
              to={"/7/profile"}
            >
              <Typography>Kurtis Weissnat</Typography>
            </NavLink>
            <NavLink
              style={{ textDecoration: "none", color: "black" }}
              to={"/9/profile"}
            >
              <Typography>Glenna Reichert</Typography>
            </NavLink>
            <NavLink
              style={{ textDecoration: "none", color: "black" }}
              to={"/"}
            >
              <Typography>Sign Out</Typography>
            </NavLink>
          </Box>
        </Popover>
      </Box>

      <Divider />

      <Box sx={{ display: "flex", flexDirection: "row" }}>
        <Box
          sx={{
            width: "45%",
            display: "flex",
            alignItems: "center",
            flexDirection: "column",
          }}
        >
          <Avatar
            sx={{ height: 180, width: 180, borderRadius: "50%" }}
            src={profilepicture}
          />

          <Typography variant="h4">{name}</Typography>

          <Box sx={{ width: "100%" }}>
            <Stack
              spacing={2}
              sx={{
                width: "100%",
                display: "flex",
                flexDirection: "column",
              }}
            >
              <Box
                sx={{ width: "100%", display: "flex", flexDirection: "row" }}
              >
                <Box
                  sx={{
                    width: "40%",
                    display: "flex",
                    justifyContent: "flex-end",
                  }}
                >
                  <Typography variant="standard">Username</Typography>
                </Box>
                <Box
                  sx={{
                    justifyContent: "center",
                    width: "5%",
                    display: "flex",
                  }}
                >
                  :
                </Box>
                <Box sx={{ width: "55%", justifyContent: "flex-start" }}>
                  <Typography variant="standard">{username}</Typography>
                </Box>
              </Box>

              <Box
                sx={{ width: "100%", display: "flex", flexDirection: "row" }}
              >
                <Box
                  sx={{
                    width: "40%",
                    display: "flex",
                    justifyContent: "flex-end",
                  }}
                >
                  <Typography variant="standard">E-mail</Typography>
                </Box>
                <Box
                  sx={{
                    justifyContent: "center",
                    width: "5%",
                    display: "flex",
                  }}
                >
                  :
                </Box>
                <Box sx={{ width: "55%", justifyContent: "flex-start" }}>
                  <Typography variant="standard">{email}</Typography>
                </Box>
              </Box>

              <Box
                sx={{ width: "100%", display: "flex", flexDirection: "row" }}
              >
                <Box
                  sx={{
                    width: "40%",
                    display: "flex",
                    justifyContent: "flex-end",
                  }}
                >
                  <Typography variant="standard">Phone</Typography>
                </Box>
                <Box
                  sx={{
                    justifyContent: "center",
                    width: "5%",
                    display: "flex",
                  }}
                >
                  :
                </Box>
                <Box sx={{ width: "55%", justifyContent: "flex-start" }}>
                  <Typography variant="standard">{phone}</Typography>
                </Box>
              </Box>

              <Box
                sx={{ width: "100%", display: "flex", flexDirection: "row" }}
              >
                <Box
                  sx={{
                    width: "40%",
                    display: "flex",
                    justifyContent: "flex-end",
                  }}
                >
                  <Typography variant="standard">Website</Typography>
                </Box>
                <Box
                  sx={{
                    justifyContent: "center",
                    width: "5%",
                    display: "flex",
                  }}
                >
                  :
                </Box>
                <Box sx={{ width: "55%", justifyContent: "flex-start" }}>
                  <Typography variant="standard">{website}</Typography>
                </Box>
              </Box>
            </Stack>
          </Box>

          <Divider />

          <Typography variant="h4">Company</Typography>
          <Box sx={{ display: "flex", flexDirection: "row", width: "100%" }}>
            <Stack
              spacing={4}
              sx={{
                width: "100%",
                display: "flex",
                flexDirection: "column",
                alignItems: "flex-end",
              }}
            >
              <Box
                sx={{
                  width: "100%",
                  display: "flex",
                  flexDirection: "row",
                }}
              >
                <Box
                  sx={{
                    width: "40%",
                    display: "flex",
                    justifyContent: "flex-end",
                  }}
                >
                  <Typography variant="standard">Name</Typography>
                </Box>
                <Box
                  sx={{
                    justifyContent: "center",
                    width: "5%",
                    display: "flex",
                  }}
                >
                  :
                </Box>
                <Box sx={{ width: "55%", justifyContent: "flex-start" }}>
                  <Typography variant="standard">{company.name}</Typography>
                </Box>
              </Box>

              <Box
                sx={{ width: "100%", display: "flex", flexDirection: "row" }}
              >
                <Box
                  sx={{
                    width: "40%",
                    display: "flex",
                    justifyContent: "flex-end",
                  }}
                >
                  <Typography variant="standard">cathaphrase</Typography>
                </Box>
                <Box
                  sx={{
                    justifyContent: "center",
                    width: "5%",
                    display: "flex",
                  }}
                >
                  :
                </Box>
                <Box sx={{ width: "55%", justifyContent: "flex-start" }}>
                  <Typography variant="standard">
                    {company.catchPhrase}
                  </Typography>
                </Box>
              </Box>

              <Box
                sx={{ width: "100%", display: "flex", flexDirection: "row" }}
              >
                <Box
                  sx={{
                    width: "40%",
                    display: "flex",
                    justifyContent: "flex-end",
                  }}
                >
                  <Typography variant="standard">bs</Typography>
                </Box>
                <Box
                  sx={{
                    justifyContent: "center",
                    width: "5%",
                    display: "flex",
                  }}
                >
                  :
                </Box>
                <Box sx={{ width: "55%", justifyContent: "flex-start" }}>
                  <Typography variant="standard">{company.bs}</Typography>
                </Box>
              </Box>
            </Stack>
          </Box>
        </Box>

        <Box sx={{ width: "55%", height: "fit-content" }}>
          <Box sx={{ paddingBottom: "15px" }}>
            <Typography variant="standard">Address:</Typography>
          </Box>

          <Box sx={{ display: "flex", flexDirection: "row", width: "100%" }}>
            <Stack
              spacing={4}
              sx={{
                width: "100%",
                display: "flex",
                flexDirection: "column",
                alignItems: "flex-end",
              }}
            >
              <Box
                sx={{
                  width: "100%",
                  display: "flex",
                  flexDirection: "row",
                }}
              >
                <Box
                  sx={{
                    width: "10%",
                    display: "flex",
                    justifyContent: "flex-end",
                  }}
                >
                  <Typography variant="standard">Street</Typography>
                </Box>
                <Box
                  sx={{
                    justifyContent: "center",
                    width: "5%",
                    display: "flex",
                  }}
                >
                  :
                </Box>
                <Box sx={{ width: "30%", justifyContent: "flex-start" }}>
                  <Typography variant="standard">{address.street}</Typography>
                </Box>
              </Box>

              <Box
                sx={{ width: "100%", display: "flex", flexDirection: "row" }}
              >
                <Box
                  sx={{
                    width: "10%",
                    display: "flex",
                    justifyContent: "flex-end",
                  }}
                >
                  <Typography variant="standard">City</Typography>
                </Box>
                <Box
                  sx={{
                    justifyContent: "center",
                    width: "5%",
                    display: "flex",
                  }}
                >
                  :
                </Box>
                <Box sx={{ width: "30%", justifyContent: "flex-start" }}>
                  <Typography variant="standard">{address.city}</Typography>
                </Box>
              </Box>

              <Box
                sx={{ width: "100%", display: "flex", flexDirection: "row" }}
              >
                <Box
                  sx={{
                    width: "10%",
                    display: "flex",
                    justifyContent: "flex-end",
                  }}
                >
                  <Typography variant="standard">Suite</Typography>
                </Box>
                <Box
                  sx={{
                    justifyContent: "center",
                    width: "5%",
                    display: "flex",
                  }}
                >
                  :
                </Box>
                <Box sx={{ width: "30%", justifyContent: "flex-start" }}>
                  <Typography variant="standard">{address.suite}</Typography>
                </Box>
              </Box>
              <Box
                sx={{ width: "100%", display: "flex", flexDirection: "row" }}
              >
                <Box
                  sx={{
                    width: "10%",
                    display: "flex",
                    justifyContent: "flex-end",
                  }}
                >
                  <Typography variant="standard">ZipCode</Typography>
                </Box>
                <Box
                  sx={{
                    justifyContent: "center",
                    width: "5%",
                    display: "flex",
                  }}
                >
                  :
                </Box>
                <Box sx={{ width: "30%", justifyContent: "flex-start" }}>
                  <Typography variant="standard">{address.zipcode}</Typography>
                </Box>
              </Box>
            </Stack>
          </Box>
          <Box sx={{ width: "100%", height: "40%", overflow: "hidden" }}>
            <Avatar
              sx={{
                height: "300px",
                width: "90%",
                borderRadius: "10px",
              }}
              src="https://media.wired.com/photos/59269cd37034dc5f91bec0f1/master/w_2560%2Cc_limit/GoogleMapTA.jpg"
            />
            <Box
              sx={{
                display: "flex",
                flexDirection: "row",
                justifyContent: "space-between",
                width: "90%",
              }}
            >
              <Typography>Latitude:{address.geo.lat}</Typography>
              <Typography>Longitude:{address.geo.lng}</Typography>
            </Box>
          </Box>
          <Box
            sx={{
              width: "100%",
              //background: "grey",
              height: "50%",
              display: "flex",
              justifyContent: "flex-end",
            }}
          >
            <Box
              sx={{
                alignItems: "flex-end",
                display: "flex",
                justifyContent: "flex-end",
                width: "50%",

                paddingRight: "20px",
              }}
            >
              <Box
                sx={{
                  width: "50%",
                  background: "blue",
                  height: "4vh",
                  borderRadius: "10px",
                  display: "flex",
                  flexDirection: "row",
                }}
              >
                <Box
                  aria-describedby={id}
                  onClick={handleClickChat}
                  sx={{
                    width: "50%",
                    background: "#ef060630",
                    height: "4vh",
                    borderRadius: "10px",
                    display: "flex",
                    flexDirection: "row",
                  }}
                >
                  <Box
                    sx={{
                      display: "flex",
                      flexDirection: "row",
                      justifyContent: "space-between",
                    }}
                  >
                    <ChatBubbleOutlineIcon />
                    <Typography>Chats</Typography>
                  </Box>

                  <KeyboardArrowUpIcon />
                </Box>
                <Popover
                  id={id}
                  open={opn}
                  anchorElChat={anchorElChat}
                  onClose={handleCloseChat}
                  anchorReference="anchorElChat"
                  anchorOrigin={{
                    vertical: "bottom",
                    horizontal: "right",
                  }}
                  transformOrigin={{
                    vertical: "top",
                    horizontal: "left",
                  }}
                >
                  <Stack
                    sx={{
                      paddingTop: "10px",
                      height: "300px",
                      overflowY: "scroll",
                    }}
                  >
                    {data.map((item) => {
                      return (
                        <Box
                          sx={{
                            display: "flex",
                            flexDirection: "row",
                            alignItems: "center",
                            width: "250px",
                            paddingLeft: "20px",
                            paddingBottom: "20px",
                          }}
                        >
                          <Avatar src={item.profilepicture} />
                          <Typography>{item.name}</Typography>
                          <Box
                            sx={{
                              backgroundColor: "green",
                              height: "6px",
                              width: "6px",
                              borderRadius: "50%",
                            }}
                          ></Box>
                          <Divider />
                        </Box>
                      );
                    })}
                  </Stack>
                </Popover>
              </Box>
            </Box>
          </Box>
        </Box>
      </Box>
    </Box>
  );
};

export default Profile;
